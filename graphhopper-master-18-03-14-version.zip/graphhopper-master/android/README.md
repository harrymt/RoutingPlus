This is a simple Eclipse project which uses graphhoppers routing and mapsforge to display the map.

* Download the apk [here](http://graphhopper.com/#download)
* More information about setup, maps creation etc is [in the wiki](https://github.com/graphhopper/graphhopper/wiki/Android)

![simple routing](http://karussell.files.wordpress.com/2012/09/graphhopper-android.png)
