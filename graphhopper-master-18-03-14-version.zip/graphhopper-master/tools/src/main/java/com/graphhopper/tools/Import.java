package com.graphhopper.tools;

import com.graphhopper.GraphHopper;

/**
 * @author Peter Karich
 */
public class Import
{
    public static void main( String[] args ) throws Exception
    {
        GraphHopper.main(args);
    }
}
