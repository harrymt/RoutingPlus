[Members](https://github.com/graphhopper?tab=members) and [Contributors](https://github.com/graphhopper/graphhopper/contributors)

 * agouge, discussion and API refactoring
 * daisy1754, fixed usage of graphhopper.sh script
 * fredao, translations
 * jansonhanson, general host config
 * karussell, lead developer
 * khuebner, pushes turn instructions forward
 * lmar, improved instructions
 * NopMap, massive improvements regarding OSM, parsing and encoding, route relations
 * ocampana, initial implementation for instructions
 * ratrun, route relations and bike handling
 * rodo, more descriptions